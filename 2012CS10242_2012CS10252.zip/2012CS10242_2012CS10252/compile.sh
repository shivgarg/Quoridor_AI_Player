g++ Board.cpp client.cpp -O1 -O2 -O3 -Ofast -o bot
